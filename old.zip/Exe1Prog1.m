% rng(1);
number = 20;
mx = 2;
sX = 3;
X = lognrnd(mx, sX, 1, number);

my = 0;
sY = 4;
Y = lognrnd(my, sY, 1, number);

lambda = 0;
Zx = Exe1Func1(X, lambda);
Zy = Exe1Func1(Y, lambda);

Hp_cnt = 0;
Hrand_cnt = 0;

fprintf('mean Zy: %.4f\n', mean(Zy));
fprintf('mean Zx: %.4f\n', mean(Zx));

for i = 1:100
    % Parametric t-test
    alpha = 0.05; 
    [Hp, P, CI] = ttest2(Zx, Zy, 'Alpha', alpha);
    Hp_cnt = Hp_cnt + Hp;
    
    % Fixed Randomization test
    B = 10000; 
    n = numel(Zx); 
    m = numel(Zy);                    
    XY = [Zx, Zy];  % Concatenate as row vector
    
    boot = NaN(B, 1);                               
    for b = 1:B
        % Randomly permute the combined data
        perm_idx = randperm(n + m);
        s = XY(perm_idx);
        boot(b) = mean(s(1:n)) - mean(s(n+1:end)); 
    end
    
    Tobs = mean(Zx) - mean(Zy);
    boot = sort(boot);
    q = quantile(boot, [alpha/2, 1 - alpha/2]);
    Hr = (Tobs < q(1)) || (Tobs > q(2));           
    Hrand_cnt = Hrand_cnt + Hr;
end

fprintf(['Before: \nfor my = %d: \n' ...
    'parametric %d times\n' ...
    'random %d times\n'], my, Hp_cnt, Hrand_cnt);

Hp_cnt = 0;
Hrand_cnt = 0;
fprintf('mean X: %.4f\n', mean(X));
fprintf('mean Y: %.4f\n', mean(Y));

for i = 1:100
    % Parametric t-test
    alpha = 0.05; 
    [Hp, P, CI] = ttest2(X, Y, 'Vartype', 'unequal', 'Alpha', alpha);
    Hp_cnt = Hp_cnt + Hp;
    
    % Fixed Randomization test
    B = 10000; 
    n = numel(X); 
    m = numel(Y);                    
    XY = [X, Y];  % Concatenate as row vector
    
    boot = NaN(B, 1);                               
    for b = 1:B
        % Randomly permute the combined data
        perm_idx = randperm(n + m);
        s = XY(perm_idx);
        boot(b) = mean(s(1:n)) - mean(s(n+1:end)); 
    end
    
    Tobs = mean(X) - mean(Y);
    boot = sort(boot);
    q = quantile(boot, [alpha/2, 1 - alpha/2]);
    Hr = (Tobs < q(1)) || (Tobs > q(2));           
    Hrand_cnt = Hrand_cnt + Hr;
end

fprintf(['for my = %d: \n' ...
    'parametric %d times\n' ...
    'random %d times\n'], my, Hp_cnt, Hrand_cnt);