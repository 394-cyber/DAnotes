data = readtable("DataEx2.dat");

richter = data.Var4;
size_data = size(richter);
n = size_data(1);

mat = cumsum(tabulate(richter),1);
M = mat(:,1);
FM = mat(:, 3) ./ 100;

N = n * (1 - FM);


mdl = fitlm(M, N, 'linear');

yfit = predict(mdl, M);

figure;
scatter(M, N);
hold on;
plot(M, yfit, 'r');

% The model doesn't seem accurate
mdl.CoefficientNames

ci = coefCI(mdl)
