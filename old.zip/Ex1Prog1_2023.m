% Constants
% Define constants for analysis
number = 100; % Number of random samples
days = 14; % Number of days to analyze
withnaan = false;

% Load Data
filename = 'EnergyHolHour.dat';
energyData = load(filename);

% energy = energyData(:, 1);
% time = energyData(:, 2);
% isHoliday = energyData(:, 3);

hourCombinations = [0 4 8 12 16 20];

% Form pairs for each combination
hourPairs = nchoosek(hourCombinations, 2);


% This returns random samples (their rows)
% randomSamples: 100 samples x days
for i = 1:size(hourPairs, 1)
    randomSamples = datasample(energyData, )
    layerSamplesRows = Ex1Func2_2023(hourPairs(i, :), days, filename, number, withnaan);


    randSampleValue
end









