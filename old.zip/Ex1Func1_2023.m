function samples = Ex1Func1_2023(hourPair, days, filename, number, withnaan)
        % Load the energy data
        energyData = load(filename);
        h1 = hourPair(1);
        h2 = hourPair(2);

        
        if h1 > h2
            % Swap hours if h1 is greater than h2
            temp = h1;
            h1 = h2;
            h2 = temp;
        end
                
        % Initialize samples array
        samples = zeros(number, days, 2);
        % samples, size of samples, sample size, rows (h1 and h2)

        h1Rows = find(energyData(:, 2) == h1);
        
        for n = 1:number
            for d = 1:days
                % Extract energy data for the specified hours and day
                
                h1RowRandom = randsample(h1Rows, 1);
                % To ensure h2 is in the same day
                h2RowRandom = h1RowRandom + h2 - h1;
    
                sampleEnergy1 = energyData(h1RowRandom, 1);
                sampleEnergy2 = energyData(h2RowRandom, 1);

                if ~ withnaan
                    while isnan(sampleEnergy1) || isnan(sampleEnergy2)
                        h1RowRandom = randsample(h1Rows, 1);
                        h2RowRandom = h1RowRandom + h2 - h1;
    
                        sampleEnergy1 = energyData(h1RowRandom, 1);
                        sampleEnergy2 = energyData(h2RowRandom, 1);
                    end
                end
                
                % Store the sampled energy data
                samples(n, d, 1) = h1RowRandom;
                samples(n, d, 2) = h2RowRandom;
           
            end

            datasample()
        end
    end